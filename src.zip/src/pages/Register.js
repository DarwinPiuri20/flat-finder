
import UserForm from '../components/UserForm'

export default function Register() {


    return (
        <div className=' bg-white  items-center justify-center '>
            <UserForm/>
        </div>
    )
}